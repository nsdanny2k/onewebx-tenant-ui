# OneWebX Tenant UI

A minimal React + Vite project for Cloudflare Pages.