import React from 'react';
import ReactDOM from 'react-dom/client';

const App = () => <h1>Hello from OneWebX Tenant UI</h1>;

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
